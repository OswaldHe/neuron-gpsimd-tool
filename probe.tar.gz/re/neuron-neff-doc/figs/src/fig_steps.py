"""Case-study figures: the GDN kernel, one illustration per optimization step, the NKI-vs-NEFF
attribution, and the control-surface overview."""
import csv
import json
import os
from collections import defaultdict

import numpy as np
import pandas as pd
from matplotlib.patches import Patch

from diagram import arrow, box, canvas, label
from fig_data import DATA, draw_timeline, legend
from style import (AQUA, AXIS, BLUE, GREEN, GRID, INK, INK2, LIGHT_BLUE, LIGHT_GRAY, LIGHT_ORANGE,
                   MAGENTA, MUTED, ORANGE, RED, SURFACE, VIOLET, YELLOW, plt, save_fig)

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
TINT = {BLUE: LIGHT_BLUE, ORANGE: LIGHT_ORANGE, AQUA: "#d3f1e6", YELLOW: "#fbecc7",
        VIOLET: "#e2def8", MAGENTA: "#f9e2eb", GREEN: "#d2ead2", RED: "#f8d9d9", MUTED: LIGHT_GRAY}
CAT = {"nki": ("achievable in NKI", BLUE),
       "hard": ("hard in NKI", VIOLET),
       "neff": ("NEFF-only (no NKI construct)", ORANGE)}


def save(fig, name):
    save_fig(fig, os.path.join(OUT, name))


def gdn_kernel():
    fig, ax = canvas(10, 2.45, 118)
    y, h, w = 16, 11, 16
    st = [(1, "Input\nprojections\n(4 matmuls)", "", BLUE),
          (27, "Convolution\n(window 4)\n+ SiLU", "", VIOLET),
          (53, "Split by head,\nrepeat query\nand key heads", "", BLUE),
          (79, "Gated delta rule\n(one recurrent\nstep per head)",
           "", VIOLET)]
    for x, t, sub, c in st:
        box(ax, x, y, w, h, t, fc=TINT[c], ec=c, size=11, weight="semibold")
        if sub:
            label(ax, x + w / 2, y - 1.3, sub, size=10.5, ha="center", va="top")
    for x, n in ((17, "query,\nkey, value"), (43, "conv\noutput"), (69, "per-head\ninputs")):
        arrow(ax, x + 0.3, y + 3.5, x + 9.7, y + 3.5, color=ORANGE, lw=1.6)
        box(ax, x + 0.35, y + 5.2, 9.3, 5.6, n, fc=TINT[ORANGE], ec=ORANGE, size=10, radius=0.5)
    box(ax, 101, y, 16, h, "output\n+ updated\nstates", fc=LIGHT_GRAY, ec=AXIS, size=11)
    arrow(ax, 95.3, y + h / 2, 100.7, y + h / 2)
    label(ax, 1, 12.6, "Config: batch 1, one token, hidden size 128, 2 key heads repeated to 4 value heads, "
          "head dim 128, bf16 weights and activations, fp32 state", size=10.5, color=INK2)
    save(fig, "fig06_gdn_kernel.png")


def step1():
    fig, ax = canvas(9, 5.3, 100)
    sbuf = dict(fc=LIGHT_BLUE, ec=BLUE, size=10)
    label(ax, 1, 57.5, "Before: a per-partition copy routed through DRAM", size=11.5, weight="semibold",
          color=INK)
    box(ax, 1, 41, 15, 11.5, "SBUF X\n128 partitions\nx 2 B", **sbuf)
    box(ax, 42.5, 41, 15, 11.5, "DRAM\ntmp-buf\n256 B", fc=LIGHT_ORANGE, ec=ORANGE, size=10)
    box(ax, 84, 41, 15, 11.5, "SBUF Y\n128 partitions\nx 4 B", **sbuf)
    arrow(ax, 16.3, 46.75, 42.2, 46.75, color=ORANGE, lw=1.8)
    label(ax, 29.25, 49.6, "writer DMA, 2-B elements", size=10, ha="center")
    arrow(ax, 57.8, 46.75, 83.7, 46.75, color=AQUA, lw=1.8)
    label(ax, 70.75, 49.6, "reader DMA, bf16 -> fp32", size=10, ha="center")
    label(ax, 50, 38.3, "the writer completes ~17-22 µs after issue; only then may the reader start",
          size=10.5, ha="center", color=ORANGE)
    label(ax, 1, 33, "After: two fields swapped, same semaphores", size=11.5, weight="semibold",
          color=INK)
    box(ax, 1, 16.5, 15, 11.5, "SBUF X\n128 partitions\nx 2 B", **sbuf)
    box(ax, 84, 16.5, 15, 11.5, "SBUF Y\n128 partitions\nx 4 B", **sbuf)
    arrow(ax, 16.3, 24.5, 83.7, 24.5, color=BLUE, lw=1.8)
    label(ax, 50, 26.7, "writer: src X -> dst Y (cast on the way)", size=10, ha="center")
    arrow(ax, 16.3, 20, 83.7, 20, color=MUTED, lw=1.4, ls=(0, (3, 2)))
    label(ax, 50, 17.6, "reader: the same copy again (idempotent)", size=10, ha="center", color=MUTED)
    label(ax, 50, 13.8, "the writer's completion now means 'Y is ready': ~2 µs, no wait changed",
          size=10.5, ha="center", color=BLUE)
    label(ax, 1, 9.6, "NEFF edit: in each writer, copy the reader's destination address and pattern; in each "
          "reader, copy the\nwriter's source (PSEUDO_DMA_DIRECT2D bytes 16-63 / SP0.json descriptors). Every "
          "semaphore and wait stays\nas the compiler emitted it, so the change cannot break synchronisation. "
          "6 buffers, outputs bit-identical.", size=10, color=INK2, va="top")
    save(fig, "step1_roundtrip_detail.png")


def step2():
    fig, ax = canvas(9, 3.9, 100)
    mono = dict(family="monospace", size=10)
    label(ax, 1, 41.5, "A DMA whose bytes someone else already moves, replaced by a semaphore increment",
          size=11.5, weight="semibold", color=INK)
    box(ax, 1, 26, 98, 11.5, "", fc=LIGHT_ORANGE, ec=ORANGE)
    label(ax, 3, 34.6, "before: PSEUDO_DMA_DIRECT2D  (Sync Engine slot 13)", weight="bold", color=INK, **mono)
    label(ax, 3, 31.4, "wait S[72] >= 16      semaphore=62  +16 on completion", **mono)
    label(ax, 3, 28.3, "issue ~0.55 µs, completion lands 2-7 µs later", size=10, color=ORANGE)
    arrow(ax, 50, 25.7, 50, 22.3, lw=1.6)
    box(ax, 1, 10, 98, 12, "", fc=LIGHT_GRAY, ec=AXIS)
    label(ax, 3, 19.1, "after: EVENT_SEMAPHORE  (same slot, same 64 bytes)", weight="bold", color=INK, **mono)
    label(ax, 3, 15.9, "wait S[72] >= 16      SEM_ADD_IMM_COMPLETE  S[62] += 16", **mono)
    label(ax, 3, 12.8, "~0.03 µs; S[62] moves the instant the real producer is done", size=10, color=INK2)
    label(ax, 1, 7.6, "Every waiter on S[62] is untouched. Update mode 21 (SEM_ADD_IMM_COMPLETE) is in the ISA "
          "enum, but the compiler\nnever emits it; the compiled kernels only use '+1 on completion' (mode 19). "
          "Trap: the wait threshold and the\nadd amount share one 4-byte value field.", size=10, color=INK2,
          va="top")
    save(fig, "step2_sem_add_detail.png")


def step3():
    fig, axes = plt.subplots(2, 1, figsize=(9, 4.3), sharex=True)
    rows = [("Scalar", "Scalar Engine"), ("GpSimd", "GPSIMD Engine"), ("Sync", "Sync Engine")]
    end = {}
    for ax, it in zip(axes, (2, 3)):
        draw_timeline(ax, it, 88, rows=rows, dma=False)
        t = pd.read_csv(os.path.join(DATA, f"timeline_iter{it}.csv"))
        end[it] = t.e_us.max()
        ax.axvline(end[it], color=INK, lw=1.4, ls=(0, (4, 2)))
        ax.text(end[it] + 0.6, 0.5, f"ends at\n{end[it]:.1f} µs", transform=ax.get_xaxis_transform(),
                va="center", fontsize=10, color=INK)
    axes[0].set_title("Before (iter 2): the GPSIMD Engine issues 25 weight-load DMAs back to back at the start",
                      fontsize=11)
    axes[1].set_title(f"After (iter 3): 8 of them move to the Scalar Engine's unused DMA queues; "
                      f"the kernel ends {end[2] - end[3]:.1f} µs earlier", fontsize=11)
    axes[1].set_xlabel("time since the kernel's first instruction (µs)")
    fig.subplots_adjust(hspace=0.55)
    legend(fig, 0.0, classes=[c for c in __import__("fig_data").CLASSES[:4]])
    save(fig, "fig10_step3_queues.png")


def step4():
    fig, ax = canvas(9, 3.75, 100)
    label(ax, 1, 40.5, "Activation-table loads in the per-head tail (1.283 µs each)", size=11.5,
          weight="semibold", color=INK)

    def ribbon(y, seq, title):
        label(ax, 1, y + 8, title, size=10.5, color=INK2)
        x = 1
        for kind in seq:
            if kind in ("L2", "L4"):
                box(ax, x, y, 4.5, 5.5, kind.replace("L", "load\n"), fc=YELLOW, ec=YELLOW, size=9,
                    radius=0.4, color=INK)
                x += 4.95
            else:
                c = {"s": GREEN, "r": VIOLET, "a": MUTED}[kind]
                box(ax, x, y, 2.2, 5.5, "", fc=c, ec=c, radius=0.4)
                x += 2.65
        return x
    before = ["L4", "r", "r", "a", "L2", "s", "L4", "r", "a", "a", "L2", "s", "s", "s", "a", "L4",
              "r", "a", "L2", "s", "L4", "r", "r", "a", "L2", "s", "L4", "r", "a"]
    after = ["L4", "r", "r", "a", "L2", "s", "s", "s", "s", "s", "s", "a", "a", "L4", "r", "a",
             "r", "r", "a", "r", "a", "a"]
    ribbon(27.5, before, "compiled order")
    ribbon(14.5, after, "after steps 4-5")
    for c, n, x in ((GREEN, "silu (needs table 2)", 1), (VIOLET, "rsqrt (needs table 4)", 28),
                    (MUTED, "table-agnostic (square, copy, CAST)", 56)):
        box(ax, x, 8.2, 2.2, 3.2, "", fc=c, ec=c, radius=0.3)
        label(ax, x + 3.2, 9.8, n, size=10)
    save(fig, "fig11_step4_tables.png")


def step5():
    """Partition->row transpose of four vectors: 512 descriptors, or pack first and use 128."""
    fig, ax = canvas(9, 4.9, 100)
    cw, ch = 2.9, 2.5
    vec = [("A", BLUE), ("B", VIOLET), ("C", GREEN), ("D", ORANGE)]

    def cell(x, y, v, i, c, hi=False):
        box(ax, x, y, cw - 0.25, ch - 0.25, f"{v}{i}", fc=c, ec=INK if hi else c, size=7.5, radius=0.25,
            color="white", lw=1.6 if hi else 1.0)

    def columns(x0, ytop, packed):
        for p in range(4):
            y = ytop - p * ch
            label(ax, x0 - 1, y + ch / 2 - 0.1, f"p{p}", size=9, ha="right", color=MUTED)
            for k, (v, c) in enumerate(vec):
                cell(x0 + k * (cw if packed else cw + 1.4), y, v, p, c)
        label(ax, x0 + (2 * cw if packed else 2 * cw + 2.1), ytop - 4 * ch + 0.9, "...", size=11,
              ha="center", color=MUTED)

    def row(x0, y, seq, hi=None):
        label(ax, x0 - 1, y + ch / 2 - 0.1, "p0", size=9, ha="right", color=MUTED)
        for k, item in enumerate(seq):
            if item is None:
                label(ax, x0 + k * cw + cw / 2, y + ch / 2 - 0.1, "...", size=11, ha="center", color=MUTED)
            else:
                v, i, c = item
                cell(x0 + k * cw, y, v, i, c, hi=(v == hi))
        return x0 + len(seq) * cw

    # before: column layout -> row layout, one descriptor per value
    label(ax, 1, 49, "Before: the DMA moves each value separately (4 x 128 = 512 descriptors)",
          size=11, weight="semibold", color=INK)
    label(ax, 8, 44.2, "column: one value per partition", size=9.5, color=INK2)
    columns(8, 40, packed=False)
    arrow(ax, 2.6, 42.5, 2.6, 32.8, color=MUTED, lw=1.2)
    label(ax, 1.4, 37.6, "partitions", size=9, color=MUTED, rotation=90, ha="center")
    arrow(ax, 27, 36.5, 34, 36.5)
    label(ax, 37, 41.4, "row: each vector along one partition", size=9.5, color=INK2)
    seq = []
    for v, c in vec:
        seq += [(v, i, c) for i in range(3)] + [None]
    xe = row(37, 35.3, seq)
    arrow(ax, 37, 33.6, xe - 1, 33.6, color=MUTED, lw=1.2)
    label(ax, 37, 31.9, "free axis: A is read as 128 values in a row, stride 1", size=9, color=MUTED, va="top")
    # after: pack inside each partition, then one descriptor per partition
    label(ax, 1, 25.5, "After: pack each partition first, then one descriptor per partition (128)",
          size=11, weight="semibold", color=INK)
    columns(8, 18.5, packed=False)
    arrow(ax, 27, 15, 35, 15)
    label(ax, 31, 17.4, "4 CASTs:\ncopy within\neach partition", size=8.5, ha="center", va="bottom")
    label(ax, 40, 22.2, "8 bytes per partition", size=9.5, color=INK2)
    columns(40, 18.5, packed=True)
    arrow(ax, 52.5, 15, 59, 15)
    label(ax, 55.7, 16.8, "one DMA", size=8.5, ha="center")
    label(ax, 62, 17.6, "interleaved row in partition 0", size=9.5, color=INK2)
    seq = [(v, i, c) for i in range(3) for v, c in vec] + [None]
    row(62, 13.8, seq, hi="A")
    label(ax, 62, 12.1, "A is read with stride 4 (A0, A1, A2, ...)", size=9, color=MUTED, va="top")
    save(fig, "fig12_step5_pack.png")


def step6():
    fig, ax = plt.subplots(figsize=(9, 3.6))
    ev = [("Sync Engine slot 18: DGE transpose (the real data)", 35.80, 36.41, BLUE, 3, (35.80, 3.38, "bottom")),
          ("S[67] += 16: its completion", 37.80, 37.80, BLUE, 3, (37.98, 3.0, "center")),
          ("Sync Engine slot 31: trigger of a 2-byte dummy DMA", 39.00, 39.10, MUTED, 2,
           (35.80, 2.38, "bottom")),
          ("S[28] += 16: dummy completes", 40.39, 40.39, MUTED, 2, (40.58, 2.0, "center"))]
    for name, s, e, c, y, (tx, ty, va) in ev:
        if e > s + 0.05:
            ax.broken_barh([(s, e - s)], (y - 0.3, 0.6), facecolors=c)
        else:
            ax.plot([s], [y], marker="v", color=c, ms=10)
        ax.text(tx, ty, name, fontsize=10, color=INK2, va=va)
    ax.broken_barh([(37.85, 0.5)], (0.7, 0.6), facecolors=GREEN)
    ax.broken_barh([(40.44, 0.5)], (0.7, 0.6), facecolors=ORANGE)
    ax.text(38.45, 1.0, "Scalar Engine slot 55\nstarts (after the edit)", fontsize=10, color=GREEN,
            va="center")
    ax.text(41.05, 1.0, "Scalar Engine slot 55\nstarts (compiled gate)", fontsize=10, color=ORANGE,
            va="center")
    ax.annotate("", xy=(37.85, 1.52), xytext=(40.44, 1.52),
                arrowprops=dict(arrowstyle="<->", color=INK, lw=1.2))
    ax.text(39.3, 1.6, "2.6 µs", ha="left", va="bottom", fontsize=10.5, color=INK, weight="semibold")
    ax.set_yticks([3, 2, 1], ["Sync Engine / DMA", "dummy", "Scalar Engine"])
    ax.set_ylim(0.3, 3.95)
    ax.set_xlim(35.4, 43.6)
    ax.set_xlabel("time (µs), iteration-5 profile")
    ax.tick_params(axis="y", length=0)
    ax.spines["left"].set_visible(False)
    ax.set_title("One byte: Scalar Engine slot 54 'wait S[28] >= 16' -> 'wait S[67] >= 16'")
    save(fig, "step6_gate_detail.png")


def step7():
    fig, ax = plt.subplots(figsize=(9, 3.1))
    for k in range(8):
        ax.broken_barh([(k * 0.69, 0.6)], (1.7, 0.6), facecolors=ORANGE if k % 2 == 0 else "#f3a07c")
    ax.text(5.7, 2.0, "8 DMAs x (0.6 µs fixed + 128 desc.) = 5.5 µs of issue", va="center",
            fontsize=10.5, color=INK2)
    ax.broken_barh([(0, 0.6 + 0.00071 * 1024)], (0.7, 0.6), facecolors=BLUE)
    ax.text(1.5, 1.0, "1 DMA x (0.6 µs + 1024 desc.) = 1.3 µs  (tile axis = dim 1 of the access pattern)",
            va="center", fontsize=10.5, color=INK2)
    ax.set_yticks([2, 1], ["8 tile loads", "merged"])
    ax.set_xlim(0, 12.6)
    ax.set_ylim(0.3, 2.6)
    ax.tick_params(axis="y", length=0)
    ax.spines["left"].set_visible(False)
    ax.set_xlabel("engine time to issue (µs), cost model fitted on the profiles")
    ax.set_title("Merging tile loads buys issue time; then split again along the consumer\n"
                 "boundary (4 + 4 tiles)")
    save(fig, "step7_merge_detail.png")


def attribution():
    rows = list(csv.DictReader(open(os.path.join(DATA, "gdn_edit_attribution.csv"))))
    lat = json.load(open(os.path.join(DATA, "gdn_latency.json")))
    meas = {i: lat[f"iter{i - 1}"]["median_us"] - lat[f"iter{i}"]["median_us"] for i in range(1, 8)}
    per = defaultdict(lambda: defaultdict(float))
    for r in rows:
        per[int(r["iter"])][r["category"]] += float(r["delta_us"])
    for i in per:  # scale the logged per-edit deltas to the re-measured per-iteration delta
        f = meas[i] / sum(per[i].values())
        for k in per[i]:
            per[i][k] *= f
    fig, (a0, a1) = plt.subplots(1, 2, figsize=(9, 4.4), gridspec_kw={"width_ratios": [1, 2.2]})
    tot1 = {k: per[1].get(k, 0) for k in CAT}
    tot2 = {k: sum(per[i].get(k, 0) for i in range(2, 8)) for k in CAT}
    for x, tot in ((0, tot1), (1, tot2)):
        b = 0
        for k, (_, c) in CAT.items():
            v = tot[k]
            a0.bar(x, v, bottom=b, color=c, width=0.6, edgecolor=SURFACE, linewidth=1.5)
            if v > 4:
                a0.text(x, b + v / 2, f"{v:.0f}", ha="center", va="center", color="white", fontsize=10.5,
                        weight="semibold")
            b += v
        a0.text(x, b + 2, f"{b:.0f} µs", ha="center", fontsize=10.5, color=INK)
    a0.set_xticks([0, 1], ["step 1", "steps 2-7"])
    a0.set_ylim(0, 140)
    a0.set_ylabel("latency removed (µs)")
    a0.yaxis.grid(True, color=GRID, lw=0.6)
    a0.set_axisbelow(True)
    xs = np.arange(2, 8)
    b = np.zeros(6)
    for k, (_, c) in CAT.items():
        v = np.array([per[i].get(k, 0) for i in xs])
        a1.bar(xs, v, bottom=b, color=c, width=0.62, edgecolor=SURFACE, linewidth=1.5)
        b += v
    for x, t in zip(xs, b):
        a1.text(x, t + 0.3, f"{t:.1f}", ha="center", fontsize=10.5, color=INK)
    a1.set_xticks(xs, [f"step {i}" for i in xs])
    a1.yaxis.grid(True, color=GRID, lw=0.6)
    a1.set_axisbelow(True)
    a1.set_ylim(0, 25)
    a1.legend(handles=[Patch(facecolor=c, label=l) for l, c in CAT.values()], loc="upper right",
              fontsize=10, handlelength=1.2)
    save(fig, "fig15_attribution.png")
    return {k: (round(tot1[k], 1), round(tot2[k], 1)) for k in CAT}


def control_surface():
    fig, ax = canvas(9.5, 5.5, 100)
    cols = [(42, "NKI 0.6 source"), (61.5, "compiler (neuronx-cc)"), (81, "NEFF edit")]
    label(ax, 0.5, 56, "Who decides what ends up in the instruction stream", size=12, weight="semibold",
          color=INK)
    for x, t in cols:
        label(ax, x + 9.25, 51.6, t, size=10.5, weight="semibold", color=INK2, ha="center")
    rows = [("which ISA op, operands, dtypes, tile shapes", "full", "lowers", "full"),
            ("where a tensor lives (SBUF/PSUM/HBM), SBUF address", "full*", "allocates", "full"),
            ("which engine runs a compute op", "most ops", "default", "any capable engine"),
            ("which engine issues a DMA", "sync / scalar / gpsimd", "default", "+ position in stream"),
            ("which DMA queue + semaphore a transfer uses", "no", "decides", "full"),
            ("DMA descriptors, queued-block triggering", "access pattern", "decides", "full"),
            ("order of instructions on one engine", "program order", "reorders", "exact"),
            ("which semaphore each instruction waits on, threshold", "no", "derives", "full"),
            ("signal without moving data (SEM_ADD_IMM)", "no", "never emits", "full"),
            ("activation-table loads: count and placement", "no", "inserts", "full")]
    marks = {"no": RED, "never emits": RED}
    for k, (what, nki, cc, neff) in enumerate(rows):
        y = 47 - k * 4.6
        if k % 2 == 0:
            box(ax, 0, y - 2.25, 100, 4.5, "", fc="#f4f3ef", ec="#f4f3ef", radius=0.3, z=0)
        label(ax, 0.8, y, what, size=10, color=INK)
        for (x, _), val, fill in ((cols[0], nki, BLUE), (cols[1], cc, MUTED), (cols[2], neff, ORANGE)):
            c = marks.get(val, fill)
            box(ax, x, y - 1.75, 18.5, 3.5, val, fc=TINT.get(c, LIGHT_GRAY), ec=c, size=9.5, radius=0.4)
    label(ax, 0.8, 1.6, "* nkilib kernels are compiled with NKI's own allocation and scheduling; "
          "reused standalone kernels still take and return HBM tensors.", size=9.5, color=INK2)
    save(fig, "control_surface_detail.png")


if __name__ == "__main__":
    gdn_kernel()
    step1()
    step2()
    step3()
    step4()
    step5()
    step6()
    step7()
    print(attribution())
    control_surface()
